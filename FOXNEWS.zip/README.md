---
license: cc-by-sa-4.0
task_categories:
- text-classification
- text-generation
language:
- en
tags:
- fox news
- news dataset
- headlines
- news articles
- text classification
- nlp dataset
---

# Curated Fox News Headlines and Full Text

This dataset contains a clean, curated collection of **Fox News articles**, including both **headlines** and **full article text**. It is designed for use in **natural language processing (NLP)** tasks such as sentiment analysis, summarization, topic classification, and media analysis.

## 📁 Dataset Format

- **Format**: CSV
- **Encoding**: UTF-8
- **Fields**:
  - `headline`: The article title or headline
  - `publish_date`: Date the article was published (YYYY-MM-DD)
  - `content`: Full article text (body of the news)

## 🔍 Use Cases

- Sentiment and bias analysis in news media
- Headline vs. body text comparison
- News summarization models
- Temporal trend or topic modeling
- Text classification and clustering

## ⚠️ Disclaimer

This dataset is provided for **educational and research purposes only**. The articles are sourced from publicly available content on Fox News. Crawlfeeds does not claim ownership of the original news content.

## 📬 Contact

For more curated news and web datasets, visit:  
👉 [https://crawlfeeds.com](https://crawlfeeds.com)